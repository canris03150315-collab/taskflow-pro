
import { 
  User, Role, DepartmentDef, DEFAULT_DEPARTMENTS, Task, Announcement, 
  Report, FinanceRecord, Suggestion, Memo, RoutineTemplate, AttendanceRecord, 
  SystemLog, PerformanceReview, ChatChannel, ChatMessage, TaskStatus, Urgency,
  MenuItemId, DEFAULT_MENU_GROUPS, MenuGroup, RoutineRecord, ReviewMetrics
} from '../types';

// ============================================================================
// CONFIGURATION
// ============================================================================

// 切換開關：true = 使用瀏覽器模擬資料庫 (單機版); false = 連接真實後端 API (連線版)
const USE_MOCK_API = false; 

// 真實後端 API 的基礎路徑（使用相對路徑通過 Netlify 代理）
const API_BASE_URL = import.meta.env.VITE_API_URL || '/api'; 

// ============================================================================
// MOCK DATA & STORAGE (單機版資料庫)
// ============================================================================

// REMOVED: MOCK_USERS are now empty to force the Setup flow on first run.
const MOCK_DB = {
  users: [] as User[], // Empty for first run
  departments: [...DEFAULT_DEPARTMENTS],
  tasks: [] as Task[],
  announcements: [] as Announcement[],
  reports: [] as Report[],
  finance: [] as FinanceRecord[],
  suggestions: [] as Suggestion[],
  memos: [] as Memo[],
  routineTemplates: [] as RoutineTemplate[],
  attendance: [] as AttendanceRecord[],
  performance: [] as PerformanceReview[],
  logs: [] as SystemLog[],
  chatChannels: [] as ChatChannel[],
  chatMessages: [] as ChatMessage[],
  settings: {
      menuGroups: DEFAULT_MENU_GROUPS as MenuGroup[]
  }
};

const STORAGE_KEY = 'TASKFLOW_PRO_DB_V2';

const loadFromStorage = () => {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
        try {
            const parsed = JSON.parse(data);
            Object.keys(parsed).forEach(key => {
                if ((MOCK_DB as any)[key] !== undefined && parsed[key] !== undefined) {
                    (MOCK_DB as any)[key] = parsed[key];
                }
            });
            // Self-Healing
            if (MOCK_DB.attendance) {
                MOCK_DB.attendance.forEach(r => {
                    if (!r.status) r.status = r.clockOut ? 'OFFLINE' : 'ONLINE';
                });
            }
        } catch (e) {
            console.error('Failed to load mock DB', e);
        }
    }
};

const saveToStorage = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(MOCK_DB));
};

if (USE_MOCK_API) {
    loadFromStorage();
}

const delay = (ms = 400) => new Promise(resolve => setTimeout(resolve, ms));
const getLocalDateString = () => new Date().toISOString().split('T')[0];

const logSystemAction = (user: User | undefined, action: string, details: string, level: 'INFO' | 'WARNING' | 'DANGER' = 'INFO') => {
    if (!USE_MOCK_API) return; 
    const log: SystemLog = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: user?.id || 'SYSTEM',
        userName: user?.name || 'System',
        action,
        details,
        level
    };
    MOCK_DB.logs.unshift(log);
    if (MOCK_DB.logs.length > 200) MOCK_DB.logs = MOCK_DB.logs.slice(0, 200);
    saveToStorage();
};

// ============================================================================
// REAL API IMPLEMENTATION (HTTP FETCH)
// ============================================================================

const getAuthHeaders = () => {
    const token = localStorage.getItem('auth_token');
    return {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    };
};

const request = async <T>(method: string, endpoint: string, body?: any): Promise<T> => {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method,
            headers: getAuthHeaders(),
            body: body ? JSON.stringify(body) : undefined,
        });
        
        const text = await response.text();
        const data = text ? JSON.parse(text) : {};
        
        if (!response.ok) {
            // 如果後端返回錯誤訊息，使用它
            const errorMessage = data.error || `API Error: ${response.statusText}`;
            throw new Error(errorMessage);
        }
        
        return data;
    } catch (error) {
        console.error(`Request failed: ${method} ${endpoint}`, error);
        throw error;
    }
};

const RealApi = {
    auth: {
        login: async (username: string, password: string): Promise<User | undefined> => {
            const res = await request<{ user: User, token: string }>('POST', '/auth/login', { username, password });
            if (res.token) {
                localStorage.setItem('auth_token', res.token);
                return res.user;
            }
            return undefined;
        },
        setup: async (userData: any): Promise<User> => {
            const res = await request<{ user: User, token: string }>('POST', '/auth/setup', userData);
            if (res.token) {
                localStorage.setItem('auth_token', res.token);
                return res.user;
            }
            return res.user;
        },
        verify: async (): Promise<User | null> => {
            try {
                const token = localStorage.getItem('auth_token');
                if (!token) return null;
                const res = await request<{ user: User }>('POST', '/auth/verify', {});
                return res.user;
            } catch (error) {
                // Token 無效或過期，清除它
                localStorage.removeItem('auth_token');
                return null;
            }
        },
        logout: () => {
            localStorage.removeItem('auth_token');
        },
        checkSetup: async (): Promise<{ needsSetup: boolean; userCount: number }> => {
            return request<{ needsSetup: boolean; userCount: number }>('GET', '/auth/setup/check');
        }
    },
    users: {
        getAll: () => request<User[]>('GET', '/users'),
        create: async (user: User) => {
            const response = await request<{ user: User, message: string }>('POST', '/users', user);
            return response.user;
        },
        update: (user: User) => request<User>('PUT', `/users/${user.id}`, user),
        delete: (id: string) => request<void>('DELETE', `/users/${id}`)
    },
    departments: {
        getAll: () => request<DepartmentDef[]>('GET', '/departments'),
        create: async (dept: DepartmentDef) => {
            const response = await request<{ department: DepartmentDef, message: string }>('POST', '/departments', dept);
            return response.department;
        },
        update: async (dept: DepartmentDef) => {
            const response = await request<{ department: DepartmentDef, message: string }>('PUT', `/departments/${dept.id}`, dept);
            return response.department;
        },
        delete: (id: string) => request<void>('DELETE', `/departments/${id}`)
    },
    tasks: {
        getAll: async (): Promise<Task[]> => {
            const response = await request<{ tasks: any[], pagination?: any }>('GET', '/tasks');
            // 轉換 snake_case 到 camelCase
            return response.tasks.map((task: any) => ({
                id: task.id,
                title: task.title,
                description: task.description,
                urgency: task.urgency,
                deadline: task.deadline,
                createdAt: task.created_at,
                status: task.status,
                targetDepartment: task.target_department,
                assignedToUserId: task.assigned_to_user_id,
                assignedToDepartment: task.assigned_to_department,
                acceptedByUserId: task.accepted_by_user_id,
                completionNotes: task.completion_notes,
                progress: task.progress || 0,
                createdBy: task.created_by,
                isArchived: task.is_archived === 1 || task.is_archived === true,
                timeline: task.timeline || [],
                unreadUpdatesForUserIds: task.unread_updates_for_user_ids || []
            }));
        },
        create: (task: Task) => request<Task>('POST', '/tasks', task),
        update: (task: Task) => request<Task>('PUT', `/tasks/${task.id}`, task),
        updateProgress: (id: string, updates: Partial<Task>) => request<void>('PATCH', `/tasks/${id}`, updates),
        accept: (id: string) => request<{ task: any }>('POST', `/tasks/${id}/accept`, {}),
        delete: (id: string) => request<void>('DELETE', `/tasks/${id}`)
    },
    announcements: {
        getAll: () => request<Announcement[]>('GET', '/announcements'),
        create: (ann: Announcement) => request<Announcement>('POST', '/announcements', ann),
        markRead: (id: string, userId: string) => request<void>('POST', `/announcements/${id}/read`, { userId })
    },
    reports: {
        getAll: () => request<Report[]>('GET', '/reports'),
        create: (report: Report) => request<Report>('POST', '/reports', report)
    },
    finance: {
        getAll: () => request<FinanceRecord[]>('GET', '/finance'),
        create: (record: FinanceRecord) => request<FinanceRecord>('POST', '/finance', record),
        confirm: (id: string) => request<void>('POST', `/finance/${id}/confirm`),
        delete: (id: string) => request<void>('DELETE', `/finance/${id}`)
    },
    forum: {
        getAll: () => request<Suggestion[]>('GET', '/forum'),
        create: (sug: Suggestion) => request<Suggestion>('POST', '/forum', sug),
        update: (sug: Suggestion) => request<Suggestion>('PUT', `/forum/${sug.id}`, sug)
    },
    memos: {
        getAll: (userId: string) => request<Memo[]>('GET', `/memos?userId=${userId}`),
        create: (memo: Memo) => request<Memo>('POST', '/memos', memo),
        update: (memo: Memo) => request<Memo>('PUT', `/memos/${memo.id}`, memo),
        delete: (id: string) => request<void>('DELETE', `/memos/${id}`)
    },
    routines: {
        getTemplates: () => request<RoutineTemplate[]>('GET', '/routines/templates'),
        saveTemplate: (tpl: RoutineTemplate) => request<RoutineTemplate>('POST', '/routines/templates', tpl),
        deleteTemplate: (id: string) => request<void>('DELETE', `/routines/templates/${id}`),
        markAsRead: (userId: string, templateId: string) => request<void>('POST', `/routines/templates/${templateId}/read`, { userId }),
        getTodayRecord: (userId: string, deptId: string) => request<RoutineRecord | null>('GET', `/routines/today?userId=${userId}&deptId=${deptId}`),
        getHistory: () => request<RoutineRecord[]>('GET', '/routines/history'),
        toggleItem: (recordId: string, index: number, isCompleted: boolean) => request<void>('POST', `/routines/records/${recordId}/toggle`, { index, isCompleted })
    },
    chat: {
        getChannels: (userId: string) => request<ChatChannel[]>('GET', `/chat/channels?userId=${userId}`),
        getMessages: (channelId: string) => request<ChatMessage[]>('GET', `/chat/channels/${channelId}/messages`),
        sendMessage: (channelId: string, userId: string, content: string, sender: User) => request<ChatMessage>('POST', `/chat/channels/${channelId}/messages`, { userId, content, sender }),
        markRead: (channelId: string, userId: string) => request<void>('POST', `/chat/channels/${channelId}/read`, { userId }),
        createDirectChannel: (user1: string, user2: string) => request<ChatChannel>('POST', '/chat/channels/direct', { user1, user2 })
    },
    attendance: {
        getTodayStatus: (userId: string) => request<AttendanceRecord | null>('GET', `/attendance/today?userId=${userId}`),
        getHistory: () => request<AttendanceRecord[]>('GET', `/attendance/history`),
        clockIn: (userId: string) => request<AttendanceRecord>('POST', '/attendance/clock-in', { userId }),
        clockOut: (recordId: string) => request<AttendanceRecord>('POST', '/attendance/clock-out', { recordId })
    },
    performance: {
        getReviews: (period: string, userId?: string) => request<PerformanceReview[]>(`GET`, `/performance/reviews?period=${period}${userId ? `&userId=${userId}` : ''}`),
        getUserStats: (userId: string, period: string) => request<ReviewMetrics>('GET', `/performance/stats?userId=${userId}&period=${period}`),
        saveReview: (review: PerformanceReview) => request<PerformanceReview>('POST', '/performance/reviews', review)
    },
    logs: {
        getAll: () => request<SystemLog[]>('GET', '/logs')
    },
    system: {
        resetFactoryDefault: () => request<void>('POST', '/system/reset'),
        exportData: () => request<string>('GET', '/system/export'),
        importData: (json: string) => request<boolean>('POST', '/system/import', { json }),
        getSettings: () => request<{menuGroups?: MenuGroup[]}>('GET', '/system/settings'),
        saveSettings: (settings: {menuGroups?: MenuGroup[]}) => request<void>('POST', '/system/settings', settings)
    }
};

const MockApi = {
    auth: {
        login: async (username: string, password: string): Promise<User | undefined> => {
            await delay();
            return MOCK_DB.users.find(u => u.username === username && u.password === password);
        },
        setup: async (userData: any): Promise<User> => {
            await delay(1000);
            const adminUser: User = {
                ...userData,
                id: `u-admin-${Date.now()}`,
                role: Role.BOSS,
                department: 'Management',
            };
            MOCK_DB.users.push(adminUser);
            logSystemAction(adminUser, 'INITIAL_SETUP', 'Created first admin account');
            saveToStorage();
            return adminUser;
        },
        checkSetup: async (): Promise<{ needsSetup: boolean; userCount: number }> => {
            await delay();
            return { needsSetup: MOCK_DB.users.length === 0, userCount: MOCK_DB.users.length };
        }
    },
    users: {
        getAll: async (): Promise<User[]> => {
            await delay();
            return [...MOCK_DB.users];
        },
        create: async (user: User, operator?: User): Promise<User> => {
            await delay();
            MOCK_DB.users.push(user);
            logSystemAction(operator, 'CREATE_USER', `Created user ${user.name} (${user.role})`);
            saveToStorage();
            return user;
        },
        update: async (user: User, operator?: User): Promise<User> => {
            await delay();
            const idx = MOCK_DB.users.findIndex(u => u.id === user.id);
            if (idx !== -1) {
                MOCK_DB.users[idx] = user;
                logSystemAction(operator, 'UPDATE_USER', `Updated user ${user.name}`);
                saveToStorage();
            }
            return user;
        },
        delete: async (id: string, operator?: User): Promise<void> => {
            await delay();
            const user = MOCK_DB.users.find(u => u.id === id);
            MOCK_DB.users = MOCK_DB.users.filter(u => u.id !== id);
            logSystemAction(operator, 'DELETE_USER', `Deleted user ${user?.name || id}`, 'WARNING');
            saveToStorage();
        }
    },
    departments: {
        getAll: async (): Promise<DepartmentDef[]> => {
            await delay();
            return [...MOCK_DB.departments];
        },
        create: async (dept: DepartmentDef, operator?: User): Promise<DepartmentDef> => {
            await delay();
            MOCK_DB.departments.push(dept);
            logSystemAction(operator, 'CREATE_DEPT', `Created department ${dept.name}`);
            saveToStorage();
            return dept;
        },
        delete: async (id: string, operator?: User): Promise<void> => {
            await delay();
            const dept = MOCK_DB.departments.find(d => d.id === id);
            MOCK_DB.departments = MOCK_DB.departments.filter(d => d.id !== id);
            logSystemAction(operator, 'DELETE_DEPT', `Deleted department ${dept?.name || id}`, 'WARNING');
            saveToStorage();
        }
    },
    tasks: {
        getAll: async (): Promise<Task[]> => {
            await delay();
            return [...MOCK_DB.tasks];
        },
        create: async (task: Task): Promise<Task> => {
            await delay();
            MOCK_DB.tasks.unshift(task);
            saveToStorage();
            return task;
        },
        update: async (task: Task): Promise<Task> => {
            await delay();
            const idx = MOCK_DB.tasks.findIndex(t => t.id === task.id);
            if (idx !== -1) {
                MOCK_DB.tasks[idx] = task;
                saveToStorage();
            }
            return task;
        },
        updateProgress: async (id: string, updates: Partial<Task>): Promise<void> => {
             await delay();
             const idx = MOCK_DB.tasks.findIndex(t => t.id === id);
             if (idx !== -1) {
                 MOCK_DB.tasks[idx] = { ...MOCK_DB.tasks[idx], ...updates };
                 saveToStorage();
             }
        }
    },
    announcements: {
        getAll: async (): Promise<Announcement[]> => {
            await delay();
            return [...MOCK_DB.announcements];
        },
        create: async (ann: Announcement): Promise<Announcement> => {
            await delay();
            MOCK_DB.announcements.unshift(ann);
            saveToStorage();
            return ann;
        },
        markRead: async (id: string, userId: string): Promise<void> => {
            await delay();
            const ann = MOCK_DB.announcements.find(a => a.id === id);
            if (ann && !ann.readBy.includes(userId)) {
                ann.readBy.push(userId);
                saveToStorage();
            }
        }
    },
    reports: {
        getAll: async (): Promise<Report[]> => {
            await delay();
            return [...MOCK_DB.reports];
        },
        create: async (report: Report): Promise<Report> => {
            await delay();
            MOCK_DB.reports.unshift(report);
            saveToStorage();
            return report;
        }
    },
    finance: {
        getAll: async (): Promise<FinanceRecord[]> => {
            await delay();
            return [...MOCK_DB.finance];
        },
        create: async (record: FinanceRecord): Promise<FinanceRecord> => {
            await delay();
            MOCK_DB.finance.unshift(record);
            saveToStorage();
            return record;
        },
        confirm: async (id: string): Promise<void> => {
            await delay();
            const rec = MOCK_DB.finance.find(r => r.id === id);
            if (rec) {
                rec.status = 'COMPLETED';
                saveToStorage();
            }
        },
        delete: async (id: string, operator?: User): Promise<void> => {
             await delay();
             MOCK_DB.finance = MOCK_DB.finance.filter(r => r.id !== id);
             logSystemAction(operator, 'DELETE_FINANCE', `Deleted finance record ${id}`, 'WARNING');
             saveToStorage();
        }
    },
    forum: {
        getAll: async (): Promise<Suggestion[]> => {
            await delay();
            return [...MOCK_DB.suggestions];
        },
        create: async (suggestion: Suggestion): Promise<Suggestion> => {
            await delay();
            MOCK_DB.suggestions.unshift(suggestion);
            saveToStorage();
            return suggestion;
        },
        update: async (suggestion: Suggestion): Promise<Suggestion> => {
            await delay();
            const idx = MOCK_DB.suggestions.findIndex(s => s.id === suggestion.id);
            if (idx !== -1) {
                MOCK_DB.suggestions[idx] = suggestion;
                saveToStorage();
            }
            return suggestion;
        }
    },
    memos: {
        getAll: async (userId: string): Promise<Memo[]> => {
            await delay();
            return MOCK_DB.memos.filter(m => m.userId === userId);
        },
        create: async (memo: Memo): Promise<Memo> => {
            await delay();
            MOCK_DB.memos.unshift(memo);
            saveToStorage();
            return memo;
        },
        update: async (memo: Memo): Promise<Memo> => {
            await delay();
            const idx = MOCK_DB.memos.findIndex(m => m.id === memo.id);
            if(idx !== -1) {
                MOCK_DB.memos[idx] = memo;
                saveToStorage();
            }
            return memo;
        },
        delete: async (id: string): Promise<void> => {
            await delay();
            MOCK_DB.memos = MOCK_DB.memos.filter(m => m.id !== id);
            saveToStorage();
        }
    },
    chat: {
        getChannels: async (userId: string): Promise<ChatChannel[]> => {
            await delay(50);
            return MOCK_DB.chatChannels.filter(c => c.participants.includes(userId)).map(ch => {
                const messages = MOCK_DB.chatMessages.filter(m => m.channelId === ch.id);
                const lastMsg = messages.length > 0 ? messages[messages.length - 1] : undefined;
                const unread = messages.filter(m => !m.readBy.includes(userId) && m.userId !== userId).length;
                return { ...ch, lastMessage: lastMsg, unreadCount: unread };
            });
        },
        getMessages: async (channelId: string): Promise<ChatMessage[]> => {
            await delay(50);
            return MOCK_DB.chatMessages.filter(m => m.channelId === channelId);
        },
        sendMessage: async (channelId: string, userId: string, content: string, sender: User): Promise<ChatMessage> => {
            const msg: ChatMessage = {
                id: `msg-${Date.now()}`,
                channelId,
                userId,
                userName: sender.name,
                avatar: sender.avatar,
                content,
                timestamp: new Date().toISOString(),
                readBy: [userId]
            };
            MOCK_DB.chatMessages.push(msg);
            saveToStorage();
            return msg;
        },
        markRead: async (channelId: string, userId: string): Promise<void> => {
            MOCK_DB.chatMessages.forEach(m => {
                if (m.channelId === channelId && !m.readBy.includes(userId)) {
                    m.readBy.push(userId);
                }
            });
            saveToStorage();
        },
        createDirectChannel: async (userId1: string, userId2: string): Promise<ChatChannel> => {
            const existing = MOCK_DB.chatChannels.find(c => 
                c.type === 'DIRECT' && c.participants.includes(userId1) && c.participants.includes(userId2)
            );
            if (existing) return existing;
            const newCh: ChatChannel = {
                id: `dm-${Date.now()}`,
                type: 'DIRECT',
                participants: [userId1, userId2]
            };
            MOCK_DB.chatChannels.push(newCh);
            saveToStorage();
            return newCh;
        }
    },
    routines: {
        getTemplates: async (): Promise<RoutineTemplate[]> => {
            await delay();
            return [...MOCK_DB.routineTemplates];
        },
        saveTemplate: async (template: RoutineTemplate, operator?: User): Promise<RoutineTemplate> => {
            await delay();
            const localTemplate = { ...template, lastUpdated: getLocalDateString() };
            const idx = MOCK_DB.routineTemplates.findIndex(t => t.id === template.id);
            if (idx !== -1) {
                localTemplate.readBy = MOCK_DB.routineTemplates[idx].readBy || [];
                MOCK_DB.routineTemplates[idx] = localTemplate;
                logSystemAction(operator, 'UPDATE_SOP', `Updated SOP: ${template.title}`);
            } else {
                localTemplate.readBy = [];
                MOCK_DB.routineTemplates.push(localTemplate);
                logSystemAction(operator, 'CREATE_SOP', `Created SOP: ${template.title}`);
            }
            saveToStorage();
            return localTemplate;
        },
        deleteTemplate: async (id: string, operator?: User): Promise<void> => {
            await delay();
            const tpl = MOCK_DB.routineTemplates.find(t => t.id === id);
            MOCK_DB.routineTemplates = MOCK_DB.routineTemplates.filter(t => t.id !== id);
            logSystemAction(operator, 'DELETE_SOP', `Deleted SOP: ${tpl?.title || id}`, 'WARNING');
            saveToStorage();
        },
        markAsRead: async (userId: string, templateId: string): Promise<void> => {
            await delay();
            const template = MOCK_DB.routineTemplates.find(t => t.id === templateId);
            if (template) {
                if (!template.readBy) template.readBy = [];
                if (!template.readBy.includes(userId)) {
                    template.readBy.push(userId);
                    saveToStorage();
                }
            }
        },
        getTodayRecord: async (userId: string, departmentId: string): Promise<RoutineRecord | null> => { return null; },
        getHistory: async (): Promise<RoutineRecord[]> => { return []; },
        toggleItem: async () => { }
    },
    attendance: {
        getTodayStatus: async (userId: string): Promise<AttendanceRecord | null> => {
            await delay(100);
            const reversedRecords = [...MOCK_DB.attendance].reverse();
            const activeSession = reversedRecords.find(r => r.userId === userId && !r.clockOut);
            if (activeSession) return activeSession;
            const today = getLocalDateString();
            const todayRecords = MOCK_DB.attendance.filter(r => r.userId === userId && r.date === today).sort((a,b) => b.clockIn.localeCompare(a.clockIn));
            return todayRecords.length > 0 ? todayRecords[0] : null;
        },
        getHistory: async (): Promise<AttendanceRecord[]> => {
            await delay();
            return [...MOCK_DB.attendance];
        },
        clockIn: async (userId: string): Promise<AttendanceRecord> => {
            await delay();
            const record: AttendanceRecord = {
                id: `att-${Date.now()}`,
                userId,
                date: getLocalDateString(),
                clockIn: new Date().toISOString(),
                status: 'ONLINE'
            };
            MOCK_DB.attendance.push(record);
            saveToStorage();
            return record;
        },
        clockOut: async (recordId: string): Promise<AttendanceRecord> => {
            await delay();
            const record = MOCK_DB.attendance.find(r => r.id === recordId);
            if (!record) throw new Error("Record not found");
            if (record.clockOut) return record;
            record.clockOut = new Date().toISOString();
            const diffMs = Math.max(0, new Date(record.clockOut).getTime() - new Date(record.clockIn).getTime());
            record.durationMinutes = Math.floor(diffMs / 1000 / 60);
            record.status = 'OFFLINE';
            saveToStorage();
            return record;
        }
    },
    performance: {
        getReviews: async (period: string, userId?: string): Promise<PerformanceReview[]> => {
            await delay();
            let result = MOCK_DB.performance.filter(r => r.period === period);
            if (userId) result = result.filter(r => r.targetUserId === userId);
            return result;
        },
        getUserStats: async (userId: string, period: string): Promise<ReviewMetrics> => {
            await delay();
            return { taskCompletionRate: 0, sopCompletionRate: 0, attendanceRate: 100 };
        },
        saveReview: async (review: PerformanceReview): Promise<PerformanceReview> => {
            await delay();
            const idx = MOCK_DB.performance.findIndex(r => r.id === review.id);
            review.updatedAt = new Date().toISOString();
            if (idx !== -1) MOCK_DB.performance[idx] = review;
            else MOCK_DB.performance.push(review);
            saveToStorage();
            return review;
        }
    },
    logs: {
        getAll: async (): Promise<SystemLog[]> => {
            await delay();
            return [...MOCK_DB.logs];
        }
    },
    system: {
        resetFactoryDefault: async (operator: User): Promise<void> => {
            await delay(1000);
            localStorage.removeItem(STORAGE_KEY);
            window.location.reload();
        },
        exportData: async (): Promise<string> => {
            await delay();
            return JSON.stringify(MOCK_DB, null, 2);
        },
        importData: async (jsonStr: string): Promise<boolean> => {
            await delay();
            try {
                const data = JSON.parse(jsonStr);
                Object.assign(MOCK_DB, data);
                saveToStorage();
                return true;
            } catch (e) { return false; }
        },
        getSettings: async (): Promise<{menuGroups?: MenuGroup[]}> => {
            await delay();
            return MOCK_DB.settings;
        },
        saveSettings: async (settings: {menuGroups?: MenuGroup[]}): Promise<void> => {
            await delay();
            MOCK_DB.settings = { ...MOCK_DB.settings, ...settings };
            saveToStorage();
        }
    }
};

export const api = USE_MOCK_API ? MockApi : RealApi;
