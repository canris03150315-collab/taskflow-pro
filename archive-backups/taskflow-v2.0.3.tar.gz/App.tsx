
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Role, Task, TaskStatus, Urgency, User, DepartmentDef, Announcement, UNASSIGNED_DEPT_ID, Report, ReportType, DailyReportContent, TaskTimelineEntry, FinanceRecord, Suggestion, SuggestionStatus, SuggestionComment, hasPermission, MenuItemId, DEFAULT_MENU_GROUPS, MENU_LABELS, MenuGroup } from './types';
import { CreateTaskModal } from './components/CreateTaskModal';
import { Badge } from './components/Badge';
import { TaskCard } from './components/TaskCard';
import { LoginPage } from './components/LoginPage';
import { SetupPage } from './components/SetupPage';
import { SubordinateView } from './components/SubordinateView';
import { PersonnelView } from './components/PersonnelView';
import { UserModal } from './components/UserModal';
import { BulletinView } from './components/BulletinView';
import { ReportView } from './components/ReportView';
import { CreateReportView } from './components/CreateReportView';
import { FinanceView } from './components/FinanceView';
import { ForumView } from './components/ForumView'; 
import { ChatSystem } from './components/ChatSystem';
import { MemoView } from './components/MemoView';
import { CalendarView } from './components/CalendarView';
import { SystemSettingsView } from './components/SystemSettingsView';
import { DashboardView } from './components/DashboardView';
import { PerformanceView } from './components/PerformanceView'; 
import { SOPView } from './components/SOPView';
import { DepartmentDataView } from './components/DepartmentDataView';
import { api } from './services/api';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSetupMode, setIsSetupMode] = useState(false);
  const [isProcessingSetup, setIsProcessingSetup] = useState(false);

  // Data States
  const [users, setUsers] = useState<User[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [departments, setDepartments] = useState<DepartmentDef[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]); 
  const [reports, setReports] = useState<Report[]>([]); 
  const [financeRecords, setFinanceRecords] = useState<FinanceRecord[]>([]); 
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [backendVersion, setBackendVersion] = useState<string>('載入中...'); 
  
  // UI States
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [isUserModalOpen, setUserModalOpen] = useState(false);
  const [isCreatingReport, setIsCreatingReport] = useState(false);
  const [isReportProcessing, setReportProcessing] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const [currentPage, setCurrentPage] = useState<MenuItemId>('dashboard'); 
  const [boardTab, setBoardTab] = useState<'my_tasks' | 'available' | 'all' | 'archived'>('all');
  const [selectedTaskCategory, setSelectedTaskCategory] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [isCalendarExpanded, setIsCalendarExpanded] = useState(false);

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchStartDate, setSearchStartDate] = useState('');
  const [searchEndDate, setSearchEndDate] = useState('');
  const [isSearchFilterOpen, setIsSearchFilterOpen] = useState(false);
  
  const [menuGroups, setMenuGroups] = useState<MenuGroup[]>(DEFAULT_MENU_GROUPS);
  const [unreadChatCount, setUnreadChatCount] = useState(0);

  const [highlightId, setHighlightId] = useState<string | null>(null);
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);

  const taskListRef = useRef<HTMLDivElement>(null);

  const loadData = async () => {
        setIsLoading(true);
        try {
            // First check if setup is needed
            const setupStatus = await api.auth.checkSetup();
            if (setupStatus.needsSetup) {
                setIsSetupMode(true);
                setIsLoading(false);
                return;
            }

            // Try to restore login session from token
            const user = await api.auth.verify();
            if (user) {
                setCurrentUser(user);
            }

            // If setup is complete, load all data
            // Use Promise.allSettled to allow partial failures
            const results = await Promise.allSettled([
                api.users.getAll(),
                api.departments.getAll(),
                api.tasks.getAll(),
                api.announcements.getAll(),
                api.reports.getAll(),
                api.finance.getAll(),
                api.forum.getAll(),
                api.system.getSettings(),
                fetch('/api/version').then(r => r.json())
            ]);
            
            // Extract successful results
            if (results[0].status === 'fulfilled') setUsers(results[0].value);
            if (results[1].status === 'fulfilled') setDepartments(results[1].value);
            if (results[2].status === 'fulfilled') setTasks(results[2].value);
            if (results[3].status === 'fulfilled') setAnnouncements(results[3].value);
            if (results[4].status === 'fulfilled') setReports(results[4].value);
            if (results[5].status === 'fulfilled') setFinanceRecords(results[5].value);
            if (results[6].status === 'fulfilled') setSuggestions(results[6].value);
            if (results[7].status === 'fulfilled' && results[7].value.menuGroups) {
                setMenuGroups(results[7].value.menuGroups);
            }
            if (results[8].status === 'fulfilled') {
                setBackendVersion(results[8].value.version || '未知');
            }
        } catch (err) {
            console.error("Failed to load initial data", err);
        } finally {
            setIsLoading(false);
        }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (currentUser) {
        const fetchChatCount = async () => {
            const channels = await api.chat.getChannels(currentUser.id);
            const total = channels.reduce((acc, ch) => acc + (ch.unreadCount || 0), 0);
            setUnreadChatCount(total);
        };
        fetchChatCount();
        const interval = setInterval(fetchChatCount, 5000);
        return () => clearInterval(interval);
    }
  }, [currentUser]);

  const handleSetupComplete = async (adminData: any) => {
      setIsProcessingSetup(true);
      try {
          const user = await api.auth.setup(adminData);
          setUsers([user]);
          setCurrentUser(user);
          setIsSetupMode(false);
          setCurrentPage('dashboard');
      } catch (err) {
          alert('初始化失敗');
      } finally {
          setIsProcessingSetup(false);
      }
  };

  const handleLogin = async (user: User) => {
    setCurrentUser(user);
    setCurrentPage('dashboard');
    
    // Load all data after login
    try {
      const results = await Promise.allSettled([
        api.users.getAll(),
        api.departments.getAll(),
        api.tasks.getAll(),
        api.announcements.getAll(),
        api.reports.getAll(),
        api.finance.getAll(),
        api.forum.getAll(),
        api.system.getSettings()
      ]);
      
      if (results[0].status === 'fulfilled') setUsers(results[0].value);
      if (results[1].status === 'fulfilled') setDepartments(results[1].value);
      if (results[2].status === 'fulfilled') setTasks(results[2].value);
      if (results[3].status === 'fulfilled') setAnnouncements(results[3].value);
      if (results[4].status === 'fulfilled') setReports(results[4].value);
      if (results[5].status === 'fulfilled') setFinanceRecords(results[5].value);
      if (results[6].status === 'fulfilled') setSuggestions(results[6].value);
      if (results[7].status === 'fulfilled' && results[7].value.menuGroups) {
        setMenuGroups(results[7].value.menuGroups);
      }
    } catch (err) {
      console.error("Failed to load data after login", err);
    }
  };

  const handleLogout = () => {
    api.auth.logout(); // 清除 token
    setCurrentUser(null);
    setCurrentPage('dashboard');
    setBoardTab('all');
    setSelectedTaskCategory(null);
    loadData(); 
  };

  const handleAddTask = async (newTaskData: any) => {
    // Convert camelCase to snake_case for backend API
    const backendData = {
      title: newTaskData.title,
      description: newTaskData.description,
      urgency: newTaskData.urgency,
      deadline: newTaskData.deadline,
      target_department: newTaskData.targetDepartment,
      assigned_to_user_id: newTaskData.assignedToUserId,
      assigned_to_department: newTaskData.assignedToDepartment
    };
    
    const response = await api.tasks.create(backendData as any);
    // 轉換後端返回的 snake_case 到 camelCase
    const createdTask: Task = {
      id: response.task.id,
      title: response.task.title,
      description: response.task.description,
      urgency: response.task.urgency,
      deadline: response.task.deadline,
      createdAt: response.task.created_at,
      status: response.task.status,
      targetDepartment: response.task.target_department,
      assignedToUserId: response.task.assigned_to_user_id,
      assignedToDepartment: response.task.assigned_to_department,
      acceptedByUserId: response.task.accepted_by_user_id,
      completionNotes: response.task.completion_notes,
      progress: response.task.progress || 0,
      createdBy: response.task.created_by,
      isArchived: response.task.is_archived === 1 || response.task.is_archived === true,
      timeline: response.task.timeline || [],
      unreadUpdatesForUserIds: response.task.unread_updates_for_user_ids || []
    };
    setTasks([createdTask, ...tasks]);
  };

  const handleAcceptTask = async (taskId: string) => {
    if (!currentUser) return;
    try {
      const response = await api.tasks.accept(taskId);
      // 轉換後端返回的 snake_case 到 camelCase
      const updatedTask: Task = {
        id: response.task.id,
        title: response.task.title,
        description: response.task.description,
        urgency: response.task.urgency,
        deadline: response.task.deadline,
        createdAt: response.task.created_at,
        status: response.task.status,
        targetDepartment: response.task.target_department,
        assignedToUserId: response.task.assigned_to_user_id,
        assignedToDepartment: response.task.assigned_to_department,
        acceptedByUserId: response.task.accepted_by_user_id,
        completionNotes: response.task.completion_notes,
        progress: response.task.progress || 0,
        createdBy: response.task.created_by,
        isArchived: response.task.is_archived === 1 || response.task.is_archived === true,
        timeline: response.task.timeline || [],
        unreadUpdatesForUserIds: response.task.unread_updates_for_user_ids || []
      };
      setTasks(tasks.map(t => t.id === taskId ? updatedTask : t));
    } catch (error: any) {
      alert(error?.message || '接取任務失敗');
    }
  };

  const handleUpdateProgress = async (taskId: string, progress: number, note: string, isComplete: boolean) => {
    if (!currentUser) return;
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const newEntry: TaskTimelineEntry = {
        timestamp: new Date().toISOString(),
        userId: currentUser.id,
        content: note || (isComplete ? '任務結案' : '進度更新'),
        progress: progress
    };

    const unreadList = new Set(task.unreadUpdatesForUserIds || []);
    if (task.createdBy !== currentUser.id) unreadList.add(task.createdBy);
    if (currentUser.role === Role.EMPLOYEE) {
         const supervisor = users.find(u => u.role === Role.SUPERVISOR && u.department === currentUser.department);
         if(supervisor && supervisor.id !== currentUser.id) unreadList.add(supervisor.id);
    }

    const updatedTask = { 
        ...task, 
        status: isComplete ? TaskStatus.COMPLETED : TaskStatus.IN_PROGRESS, 
        completionNotes: isComplete ? note : task.completionNotes,
        progress: progress,
        timeline: [newEntry, ...(task.timeline || [])],
        unreadUpdatesForUserIds: Array.from(unreadList)
    };

    await api.tasks.update(updatedTask);
    setTasks(tasks.map(t => t.id === taskId ? updatedTask : t));
  };

  const handleArchiveTask = async (taskId: string) => {
      // 使用 snake_case 格式傳遞給後端
      await api.tasks.updateProgress(taskId, { is_archived: true });
      setTasks(tasks.map(t => t.id === taskId ? { ...t, isArchived: true } : t));
  };

  const handleEditTask = (task: Task) => {
      // 設置要編輯的任務並打開建立任務模態框
      // TODO: 需要修改 CreateTaskModal 支援編輯模式
      alert('編輯功能開發中...');
  };

  const handleDeleteTask = async (taskId: string) => {
      try {
          await api.tasks.delete(taskId);
          setTasks(tasks.filter(t => t.id !== taskId));
          alert('任務已刪除');
      } catch (error: any) {
          alert(error?.message || '刪除任務失敗');
      }
  };

  const handleAddUser = async (userData: any) => {
    try {
      const newUser: User = { ...userData, id: `u-${Date.now()}` };
      const createdUser = await api.users.create(newUser, currentUser || undefined);
      setUsers([...users, createdUser]);
      alert('用戶創建成功！');
    } catch (error: any) {
      const errorMessage = error?.message || '創建用戶失敗';
      alert(errorMessage);
      throw error; // 重新拋出錯誤，防止模態框關閉
    }
  };

  const handleUpdateUser = async (userData: any) => {
    if (!editingUser) return;
    const updatedUser = { ...editingUser, ...userData };
    await api.users.update(updatedUser, currentUser || undefined);
    setUsers(users.map(u => u.id === editingUser.id ? updatedUser : u));
    if (currentUser && currentUser.id === editingUser.id) {
        setCurrentUser(updatedUser);
    }
    setEditingUser(null);
  };

  const handleDeleteUser = async (userId: string) => {
    if (window.confirm('確定要刪除此使用者嗎？')) {
      await api.users.delete(userId, currentUser || undefined);
      setUsers(users.filter(u => u.id !== userId));
    }
  };

  const handleAddDepartment = async (dept: DepartmentDef) => {
     try {
         const createdDept = await api.departments.create(dept);
         setDepartments([...departments, createdDept]);
     } catch (error: any) {
         alert(error?.message || '創建部門失敗');
     }
  };

  const handleUpdateDepartment = async (dept: DepartmentDef) => {
      try {
          const updatedDept = await api.departments.update(dept);
          setDepartments(prev => prev.map(d => d.id === dept.id ? updatedDept : d));
      } catch (error: any) {
          alert(error?.message || '更新部門失敗');
      }
  };

  const handleDeleteDepartment = async (id: string) => {
     const hasUsers = users.some(u => u.department === id);
     if (hasUsers) {
         alert('無法刪除：該部門尚有員工，請先轉移人員。');
         return;
     }
     if (id === UNASSIGNED_DEPT_ID) {
         alert('無法刪除系統預設部門。');
         return;
     }
     await api.departments.delete(id, currentUser || undefined);
     setDepartments(departments.filter(d => d.id !== id));
  };

  const handleCreateAnnouncement = async (data: any) => {
      if(!currentUser) return;
      const newAnn: Announcement = {
          id: `ann-${Date.now()}`,
          ...data,
          createdAt: new Date().toISOString().split('T')[0],
          createdBy: currentUser.id,
          readBy: []
      };
      await api.announcements.create(newAnn);
      setAnnouncements([newAnn, ...announcements]);
  };

  const handleConfirmRead = async (annId: string) => {
      if(!currentUser) return;
      await api.announcements.markRead(annId, currentUser.id);
      setAnnouncements(announcements.map(a => 
          a.id === annId ? { ...a, readBy: [...a.readBy, currentUser.id] } : a
      ));
  };

  const handleCreateReport = async (content: DailyReportContent, type: ReportType) => {
      if(!currentUser) return;
      setReportProcessing(true);
      const newReport: Report = {
          id: `rep-${Date.now()}`,
          type,
          userId: currentUser.id,
          createdAt: new Date().toISOString().split('T')[0],
          content
      };
      await api.reports.create(newReport);
      setReports([newReport, ...reports]);
      setReportProcessing(false);
      setIsCreatingReport(false);
  };

  const handleAddFinanceRecord = async (record: Omit<FinanceRecord, 'id'>) => {
      const newRecord: FinanceRecord = { ...record, id: `fr-${Date.now()}` };
      await api.finance.create(newRecord);
      setFinanceRecords([newRecord, ...financeRecords]);
  };

  const handleConfirmFinanceRecord = async (id: string) => {
      await api.finance.confirm(id);
      setFinanceRecords(prev => prev.map(r => r.id === id ? { ...r, status: 'COMPLETED' } : r));
  };

  const handleDeleteFinanceRecord = async (id: string) => {
      await api.finance.delete(id, currentUser || undefined);
      setFinanceRecords(financeRecords.filter(r => r.id !== id));
  };

  const handleAddSuggestion = async (suggestion: Omit<Suggestion, 'id' | 'status' | 'upvotes' | 'comments' | 'createdAt'>) => {
      const newSuggestion: Suggestion = {
          ...suggestion,
          id: `sug-${Date.now()}`,
          status: SuggestionStatus.OPEN,
          upvotes: [],
          comments: [],
          createdAt: new Date().toISOString().split('T')[0]
      };
      await api.forum.create(newSuggestion);
      setSuggestions([newSuggestion, ...suggestions]);
  };

  const handleUpdateSuggestionStatus = async (id: string, status: SuggestionStatus) => {
      const sug = suggestions.find(s => s.id === id);
      if (sug) {
          const updated = { ...sug, status };
          await api.forum.update(updated);
          setSuggestions(prev => prev.map(s => s.id === id ? updated : s));
      }
  };

  const handleToggleUpvote = async (id: string) => {
      if (!currentUser) return;
      const sug = suggestions.find(s => s.id === id);
      if (sug) {
          const hasUpvoted = sug.upvotes.includes(currentUser.id);
          const newUpvotes = hasUpvoted 
              ? sug.upvotes.filter(uid => uid !== currentUser.id) 
              : [...sug.upvotes, currentUser.id];
          const updated = { ...sug, upvotes: newUpvotes };
          await api.forum.update(updated);
          setSuggestions(prev => prev.map(s => s.id === id ? updated : s));
      }
  };

  const handleAddSuggestionComment = async (suggestionId: string, content: string) => {
      if (!currentUser) return;
      let isOfficial = false;
      const suggestion = suggestions.find(s => s.id === suggestionId);
      if (currentUser.role === Role.BOSS || currentUser.role === Role.MANAGER) {
          isOfficial = true;
      } else if (currentUser.role === Role.SUPERVISOR && suggestion?.targetDeptId === currentUser.department) {
          isOfficial = true;
      }
      const newComment: SuggestionComment = {
          id: `c-${Date.now()}`,
          userId: currentUser.id,
          content,
          createdAt: new Date().toISOString().split('T')[0],
          isOfficialReply: isOfficial
      };
      if (suggestion) {
          const updated = { ...suggestion, comments: [...suggestion.comments, newComment] };
          await api.forum.update(updated);
          setSuggestions(prev => prev.map(s => s.id === suggestionId ? updated : s));
      }
  };

  const handleNotificationClick = () => {
    setCurrentPage('tasks');
    setBoardTab('my_tasks');
    setSearchQuery('');
    setSearchStartDate('');
    setSearchEndDate('');
    
    const target = tasks.find(t => (t.assignedToUserId === currentUser?.id || t.acceptedByUserId === currentUser?.id) && !t.isArchived);
    if (target) {
        setHighlightId(target.id);
        setExpandedTaskId(target.id);
        setTimeout(() => {
            if (taskListRef.current) taskListRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
        setTimeout(() => setHighlightId(null), 2500);
    }
  };

  const toggleExpandTask = (taskId: string) => {
     if (expandedTaskId !== taskId && currentUser) {
         setTasks(prevTasks => prevTasks.map(t => {
             if (t.id === taskId && t.unreadUpdatesForUserIds?.includes(currentUser.id)) {
                 return {
                     ...t,
                     unreadUpdatesForUserIds: t.unreadUpdatesForUserIds.filter(id => id !== currentUser.id)
                 };
             }
             return t;
         }));
     }
     setExpandedTaskId(prev => prev === taskId ? null : taskId);
  };

  const displayedTasks = useMemo(() => {
    if (!currentUser) return [];
    if (!Array.isArray(tasks)) return [];
    let filtered = tasks;

    if (boardTab === 'archived') {
        filtered = filtered.filter(t => t.isArchived);
    } else {
        filtered = filtered.filter(t => !t.isArchived);
        if (boardTab === 'my_tasks') {
            filtered = filtered.filter(t => t.assignedToUserId === currentUser.id || t.acceptedByUserId === currentUser.id || t.createdBy === currentUser.id);
        } else if (boardTab === 'available') {
            // 顯示公開任務 (OPEN) 或指派給當前用戶但尚未接受的任務 (ASSIGNED)
            filtered = filtered.filter(t => 
                t.status === TaskStatus.OPEN || 
                (t.status === TaskStatus.ASSIGNED && t.assignedToUserId === currentUser.id)
            );
        }
    }
    
    if (selectedDate) filtered = filtered.filter(t => t.deadline && t.deadline.startsWith(selectedDate));
    if (searchQuery) filtered = filtered.filter(t => t.title.toLowerCase().includes(searchQuery.toLowerCase()) || t.description.toLowerCase().includes(searchQuery.toLowerCase()));
    if (boardTab === 'all' && selectedTaskCategory) {
        if (selectedTaskCategory === 'OPEN') filtered = filtered.filter(t => !t.targetDepartment);
        else filtered = filtered.filter(t => t.targetDepartment === selectedTaskCategory);
    }
    return filtered;
  }, [tasks, boardTab, currentUser, searchQuery, selectedTaskCategory, selectedDate]);

  const deptGroups = useMemo(() => {
     if (boardTab !== 'all' || !currentUser) return { openTasks: [], groups: [] };
     if (!Array.isArray(displayedTasks) || !Array.isArray(departments)) return { openTasks: [], groups: [] };
     const openTasks = displayedTasks.filter(t => !t.targetDepartment);
     let visibleDepts = departments;
     if (currentUser.role === Role.EMPLOYEE) visibleDepts = departments.filter(d => d.id === currentUser.department);
     const groups = visibleDepts.map(d => ({ def: d, tasks: displayedTasks.filter(t => t.targetDepartment === d.id) }));
     return { openTasks, groups };
  }, [displayedTasks, boardTab, departments, currentUser]);

  // 計算任務通知數量
  const taskNotificationCount = useMemo(() => {
    if (!currentUser) return 0;
    return tasks.filter(t => 
      !t.isArchived && (
        // 新分配給我的任務（ASSIGNED 狀態且尚未接受）
        (t.status === TaskStatus.ASSIGNED && t.assignedToUserId === currentUser.id) ||
        // 公開任務（OPEN 狀態，任何人都可以接取）
        (t.status === TaskStatus.OPEN) ||
        // 有未讀更新的任務
        (t.unreadUpdatesForUserIds?.includes(currentUser.id))
      )
    ).length;
  }, [tasks, currentUser]);

  const getDeptName = (id: string) => departments.find(d => d.id === id)?.name || id;

  const renderSidebarItem = (id: MenuItemId) => {
      const config = MENU_LABELS[id];
      if (!config) return null;
      if (id === 'team' && !(hasPermission(currentUser!, 'CREATE_TASK') || currentUser!.role === Role.BOSS || currentUser!.role === Role.MANAGER || currentUser!.role === Role.SUPERVISOR)) return null;
      if (id === 'personnel' && !(hasPermission(currentUser!, 'MANAGE_USERS') || currentUser!.role === Role.BOSS || currentUser!.role === Role.MANAGER || currentUser!.role === Role.SUPERVISOR)) return null;
      if (id === 'settings' && !(currentUser!.role === Role.BOSS || hasPermission(currentUser!, 'SYSTEM_RESET'))) return null;
      if (id === 'data_center' && !(currentUser!.role === Role.BOSS || currentUser!.role === Role.MANAGER || currentUser!.role === Role.SUPERVISOR)) return null;

      return (
        <button 
            key={id}
            onClick={() => { setCurrentPage(id); setIsCreatingReport(false); setIsMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition font-bold ${currentPage === id ? (id === 'settings' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-700 shadow-sm') : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'}`}
        >
            <span className="text-lg">{config.icon}</span>
            {config.label}
            {id === 'tasks' && taskNotificationCount > 0 && <span className="ml-auto bg-red-100 text-red-600 px-2 py-0.5 rounded-full text-[10px] font-black">{taskNotificationCount}</span>}
            {id === 'chat' && unreadChatCount > 0 && <span className="ml-auto bg-red-100 text-red-600 px-2 py-0.5 rounded-full text-[10px] font-black">{unreadChatCount}</span>}
        </button>
      );
  };

  if (isLoading) {
      return (
          <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center">
              <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-4"></div>
              <p className="text-slate-400 font-bold">載入中...</p>
          </div>
      );
  }

  if (isSetupMode) {
      return <SetupPage onComplete={handleSetupComplete} isProcessing={isProcessingSetup} />;
  }

  if (!currentUser) {
    return <LoginPage users={users} onLogin={handleLogin} />;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen font-sans bg-slate-50 text-slate-900">
      
      {isMobileMenuOpen && (
          <div className="fixed inset-0 bg-slate-900/50 z-40 md:hidden backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)}></div>
      )}

      <aside className={`w-72 bg-white border-r border-slate-200 flex flex-col flex-shrink-0 z-50 fixed inset-y-0 left-0 transform transition-transform duration-300 md:translate-x-0 md:static ${isMobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}`}>
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center text-xl">🏢</div>
            <h1 className="text-lg font-black text-slate-800 tracking-tight leading-none">TaskFlow Pro</h1>
          </div>
          <button onClick={() => setIsMobileMenuOpen(false)} className="md:hidden text-slate-400"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
        </div>

        <div className="p-6">
          <button onClick={() => { setEditingUser(currentUser); setUserModalOpen(true); }} className="w-full text-left bg-slate-50 rounded-2xl border border-slate-200 p-4 shadow-sm group hover:border-blue-300 transition">
            <div className="flex items-center gap-3">
               <img src={currentUser.avatar} className="w-12 h-12 rounded-full border border-slate-200" />
               <div className="min-w-0">
                  <h2 className="font-bold text-slate-800 truncate">{currentUser.name}</h2>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">{getDeptName(currentUser.department)}</p>
               </div>
            </div>
          </button>
        </div>

        <nav className="flex-1 px-4 overflow-y-auto pb-4 space-y-4">
          {Array.isArray(menuGroups) && menuGroups.map(group => {
              if (!group || !Array.isArray(group.items)) return null;
              const items = group.items.map(id => renderSidebarItem(id)).filter(Boolean);
              if (items.length === 0) return null;
              return (
                  <div key={group.id} className="space-y-1">
                      <h3 className="px-4 text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 mt-2">{group.label}</h3>
                      {items}
                  </div>
              );
          })}
        </nav>

        <div className="p-4 border-t border-slate-100">
           <button onClick={handleLogout} className="w-full py-3 bg-slate-50 text-slate-500 rounded-xl font-bold hover:bg-red-50 hover:text-red-600 transition flex items-center justify-center gap-2">登出系統</button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden relative bg-white md:bg-slate-50">
        <header className="bg-white border-b border-slate-200 py-4 px-4 md:px-8 flex items-center justify-between sticky top-0 z-30">
           <div className="flex items-center gap-4">
              <button onClick={() => setIsMobileMenuOpen(true)} className="md:hidden text-slate-500"><svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"></path></svg></button>
              <h2 className="text-xl font-black text-slate-800 tracking-tight">{MENU_LABELS[currentPage]?.label}</h2>
           </div>
           <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-bold text-slate-400">已連線</span>
           </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-8">
           {currentPage === 'dashboard' && <DashboardView currentUser={currentUser} tasks={tasks} announcements={announcements} reports={reports} departments={departments} onChangePage={setCurrentPage} />}
           {currentPage === 'bulletin' && <BulletinView currentUser={currentUser} announcements={announcements} users={users} departments={departments} onCreateAnnouncement={handleCreateAnnouncement} onConfirmRead={handleConfirmRead} />}
           {currentPage === 'personnel' && <PersonnelView currentUser={currentUser} users={users} departments={departments} onAddUser={() => { setEditingUser(null); setUserModalOpen(true); }} onEditUser={(u) => { setEditingUser(u); setUserModalOpen(true); }} onDeleteUser={handleDeleteUser} onAddDepartment={handleAddDepartment} onUpdateDepartment={handleUpdateDepartment} onDeleteDepartment={handleDeleteDepartment} />}
           {currentPage === 'team' && <SubordinateView currentUser={currentUser} users={users} tasks={tasks} departments={departments} />}
           {currentPage === 'reports' && (isCreatingReport ? <CreateReportView onCancel={() => setIsCreatingReport(false)} onSubmit={handleCreateReport} isProcessing={isReportProcessing} /> : <ReportView currentUser={currentUser} users={users} reports={reports} departments={departments} onCreateClick={() => setIsCreatingReport(true)} onOpenReportModal={() => setIsCreatingReport(true)} />)}
           {currentPage === 'finance' && <FinanceView currentUser={currentUser} users={users} departments={departments} records={financeRecords} onAddRecord={handleAddFinanceRecord} onConfirmRecord={handleConfirmFinanceRecord} onDeleteRecord={handleDeleteFinanceRecord} />}
           {currentPage === 'data_center' && <DepartmentDataView currentUser={currentUser} users={users} departments={departments} tasks={tasks} reports={reports} financeRecords={financeRecords} />}
           {currentPage === 'forum' && <ForumView currentUser={currentUser} users={users} suggestions={suggestions} departments={departments} onAddSuggestion={handleAddSuggestion} onUpdateStatus={handleUpdateSuggestionStatus} onToggleUpvote={handleToggleUpvote} onAddComment={handleAddSuggestionComment} />}
           {currentPage === 'chat' && <ChatSystem currentUser={currentUser} users={users} departments={departments} />}
           {currentPage === 'memo' && <MemoView currentUser={currentUser} />}
           {currentPage === 'performance' && <PerformanceView currentUser={currentUser} users={users} departments={departments} />}
           {currentPage === 'sop' && <SOPView currentUser={currentUser} users={users} departments={departments} />}
           {currentPage === 'settings' && <SystemSettingsView currentUser={currentUser} onLogout={handleLogout} />}
           
           {currentPage === 'tasks' && (
             <div className="max-w-6xl mx-auto pb-20">
               <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl font-black text-slate-800 tracking-tight">任務看板</h2>
                  {(hasPermission(currentUser, 'CREATE_TASK') || currentUser.role === Role.BOSS || currentUser.role === Role.MANAGER || currentUser.role === Role.SUPERVISOR) && (
                    <button onClick={() => setCreateModalOpen(true)} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg transition">＋ 建立任務</button>
                  )}
               </div>
               <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
                 {['all', 'my_tasks', 'available', 'archived'].map(tab => (
                   <button key={tab} onClick={() => { setBoardTab(tab as any); setSelectedTaskCategory(null); }} className={`px-4 py-2 rounded-lg text-sm font-bold whitespace-nowrap transition ${boardTab === tab ? 'bg-slate-800 text-white' : 'bg-white text-slate-500 border border-slate-200'}`}>
                      {tab === 'all' ? '總覽' : tab === 'my_tasks' ? '我的任務' : tab === 'available' ? '待接取' : '已封存'}
                   </button>
                 ))}
               </div>
               <div className="grid grid-cols-1 gap-6">
                 {displayedTasks.map(t => <TaskCard key={t.id} task={t} currentUser={currentUser} users={users} departments={departments} onAccept={handleAcceptTask} onUpdateProgress={handleUpdateProgress} onArchive={handleArchiveTask} onEdit={handleEditTask} onDelete={handleDeleteTask} isHighlighted={t.id === highlightId} isExpanded={expandedTaskId === t.id} onToggleExpand={() => toggleExpandTask(t.id)} />)}
                 {displayedTasks.length === 0 && <div className="text-center py-20 text-slate-400 font-bold border-2 border-dashed rounded-2xl">目前沒有任務</div>}
               </div>
             </div>
           )}
        </div>
      </main>

      <CreateTaskModal isOpen={isCreateModalOpen} onClose={() => setCreateModalOpen(false)} onSubmit={handleAddTask} users={users} currentUser={currentUser} departments={departments} />
      <UserModal isOpen={isUserModalOpen} onClose={() => { setUserModalOpen(false); setEditingUser(null); }} onSubmit={editingUser ? handleUpdateUser : handleAddUser} currentUser={currentUser} editingUser={editingUser} departments={departments} />
      
      {/* 版本號顯示 */}
      <div className="fixed bottom-2 right-2 text-xs text-slate-400 bg-white/80 px-2 py-1 rounded shadow-sm">
        後端版本: {backendVersion}
      </div>
    </div>
  );
}
