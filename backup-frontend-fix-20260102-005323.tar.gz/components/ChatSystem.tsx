import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { User, DepartmentDef, ChatChannel, ChatMessage, Role } from '../types';
import { api } from '../services/api';
import { useToast } from './Toast';
import { WebSocketClient, WebSocketMessage } from '../utils/websocketClient';
import { ChatMessageReadStatusModal } from './ChatMessageReadStatusModal';
import { CreateGroupModal } from './CreateGroupModal';
import { GroupInfoModal } from './GroupInfoModal';

interface ChatSystemProps {
  currentUser: User;
  users: User[];
  departments: DepartmentDef[];
}

export const ChatSystem: React.FC<ChatSystemProps> = ({ currentUser, users, departments }) => {
  const toast = useToast();
  const [channels, setChannels] = useState<ChatChannel[]>([]);
  const [activeChannelId, setActiveChannelId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [messageInput, setMessageInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(false);
  
  // Modals
  const [showCreateGroupModal, setShowCreateGroupModal] = useState(false);
  const [showGroupInfoModal, setShowGroupInfoModal] = useState(false);
  const [readStatusMsg, setReadStatusMsg] = useState<ChatMessage | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const wsClientRef = useRef<WebSocketClient | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  // Sound
  const notificationSound = useMemo(() => new Audio('/notification.mp3'), []);

  // Initialize WebSocket
  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    const wsUrl = (import.meta as any).env?.VITE_WS_URL || 'ws://165.227.147.40:3001';
    
    wsClientRef.current = new WebSocketClient(wsUrl);
    
    const handleMessage = (event: WebSocketMessage) => {
      if (event.type === 'chat_message') {
        const newMsg = event.payload as ChatMessage;
        
        setMessages(prev => {
          // Avoid duplicates
          if (prev.some(m => m.id === newMsg.id)) return prev;
          
          // Only add if it belongs to current channel
          if (newMsg.channelId === activeChannelId) {
             return [...prev, newMsg];
          }
          return prev;
        });

        // Update channel preview and unread count
        setChannels(prev => prev.map(ch => {
            if (ch.id === newMsg.channelId) {
                const isCurrentChannel = newMsg.channelId === activeChannelId;
                return {
                    ...ch,
                    lastMessage: newMsg,
                    unreadCount: isCurrentChannel ? 0 : (ch.unreadCount || 0) + 1
                };
            }
            return ch;
        }).sort((a, b) => {
            // Sort by latest message
            const timeA = a.lastMessage?.timestamp || '';
            const timeB = b.lastMessage?.timestamp || '';
            return new Date(timeB).getTime() - new Date(timeA).getTime();
        }));

        // Play sound if not current user
        if (newMsg.userId !== currentUser.id) {
            notificationSound.play().catch(e => console.error("Audio play failed", e));
        }
      }
    };

    wsClientRef.current.addMessageHandler(handleMessage);
    wsClientRef.current.connect(token || undefined).then(() => {
        setIsConnected(true);
    }).catch(err => {
        console.error("WS Connect Error", err);
        setIsConnected(false);
    });

    return () => {
        if (wsClientRef.current) {
            wsClientRef.current.removeMessageHandler(handleMessage);
            wsClientRef.current.disconnect();
        }
    };
  }, [currentUser.id, activeChannelId, notificationSound]);

  // Load Channels
  useEffect(() => {
      loadChannels();
  }, [currentUser.id]);

  const loadChannels = async () => {
      try {
          const data = await api.chat.getChannels(currentUser.id);
          setChannels(data.sort((a, b) => {
              const timeA = a.lastMessage?.timestamp || '';
              const timeB = b.lastMessage?.timestamp || '';
              return new Date(timeB).getTime() - new Date(timeA).getTime();
          }));
      } catch (error) {
          console.error("Failed to load channels", error);
      }
  };

  // Load Messages when active channel changes
  useEffect(() => {
      if (activeChannelId) {
          loadMessages(activeChannelId);
          // Mark read
          api.chat.markRead(activeChannelId, currentUser.id);
          setChannels(prev => prev.map(ch => ch.id === activeChannelId ? { ...ch, unreadCount: 0 } : ch));
      } else {
          setMessages([]);
      }
  }, [activeChannelId]);

  const loadMessages = async (channelId: string) => {
      setIsLoading(true);
      try {
          const res = await api.chat.getMessages(channelId, { limit: 50 });
          // Messages from API are usually newest first or oldest first? 
          // Assuming API returns newest first, we reverse to display oldest at top
          // Adjust based on actual API behavior. Usually chat needs oldest at top.
          // If API returns { messages: [newest, ..., oldest] }, we reverse.
          // If API returns { messages: [oldest, ..., newest] }, we keep.
          // Let's assume standard pagination (newest first) -> reverse
          setMessages(res.messages.reverse()); 
          setHasMoreMessages(res.hasMore);
      } catch (error) {
          console.error("Failed to load messages", error);
          toast.error("載入訊息失敗");
      } finally {
          setIsLoading(false);
          scrollToBottom();
      }
  };

  const scrollToBottom = () => {
      setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!messageInput.trim() || !activeChannelId) return;

      const tempId = `temp-${Date.now()}`;
      const content = messageInput;
      setMessageInput('');

      // Optimistic update
      const tempMsg: ChatMessage = {
          id: tempId,
          channelId: activeChannelId,
          userId: currentUser.id,
          userName: currentUser.name,
          avatar: currentUser.avatar,
          content: content,
          timestamp: new Date().toISOString(),
          readBy: [currentUser.id]
      };
      
      setMessages(prev => [...prev, tempMsg]);
      scrollToBottom();

      try {
          const newMsg = await api.chat.sendMessage(activeChannelId, currentUser.id, content, currentUser);
          // Replace temp message
          setMessages(prev => prev.map(m => m.id === tempId ? newMsg : m));
          
          // Update channel list preview
          setChannels(prev => prev.map(ch => {
              if (ch.id === activeChannelId) {
                  return { ...ch, lastMessage: newMsg };
              }
              return ch;
          }).sort((a, b) => {
              const timeA = a.lastMessage?.timestamp || '';
              const timeB = b.lastMessage?.timestamp || '';
              return new Date(timeB).getTime() - new Date(timeA).getTime();
          }));

      } catch (error) {
          console.error("Send message failed", error);
          toast.error("發送失敗");
          setMessages(prev => prev.filter(m => m.id !== tempId));
          setMessageInput(content); // Restore input
      }
  };

  const handleCreateGroup = async (name: string, userIds: string[]) => {
      try {
          const newChannel = await api.chat.createGroupChannel(name, userIds);
          setChannels(prev => [newChannel, ...prev]);
          setActiveChannelId(newChannel.id);
          setShowCreateGroupModal(false);
          toast.success("群組建立成功");
      } catch (error) {
          console.error("Create group failed", error);
          toast.error("建立失敗");
      }
  };

  const handleLeaveGroup = async () => {
      if (!activeChannelId) return;
      try {
          await api.chat.leaveChannel(activeChannelId);
          setChannels(prev => prev.filter(c => c.id !== activeChannelId));
          setActiveChannelId(null);
          setShowGroupInfoModal(false);
          toast.success("已退出群組");
      } catch (error) {
          console.error("Leave group failed", error);
          toast.error("退出失敗");
      }
  };

  const handleEditGroup = async (newName: string, newMembers: string[]) => {
      if (!activeChannelId) return;
      try {
          const updatedChannel = await api.chat.editChannel(activeChannelId, newName, newMembers);
          setChannels(prev => prev.map(c => c.id === activeChannelId ? updatedChannel : c));
          setShowGroupInfoModal(false);
          toast.success("群組已更新");
      } catch (error) {
          console.error("Edit group failed", error);
          toast.error("更新失敗");
      }
  };

  const getChannelName = (channel: ChatChannel) => {
      if (channel.type === 'GROUP') return channel.name;
      // Direct: find other user
      const otherId = channel.participants.find(id => id !== currentUser.id);
      const otherUser = users.find(u => u.id === otherId);
      return otherUser?.name || 'Unknown User';
  };

  const getChannelAvatar = (channel: ChatChannel) => {
      if (channel.type === 'GROUP') return null; // Or group icon
      const otherId = channel.participants.find(id => id !== currentUser.id);
      const otherUser = users.find(u => u.id === otherId);
      return otherUser?.avatar;
  };

  const activeChannel = channels.find(c => c.id === activeChannelId);

  return (
    <div className="flex h-[calc(100vh-100px)] bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Sidebar */}
        <div className="w-80 border-r border-slate-200 flex flex-col">
            <div className="p-4 border-b border-slate-200 flex justify-between items-center">
                <h2 className="font-bold text-slate-700">聊天室</h2>
                <button 
                    onClick={() => setShowCreateGroupModal(true)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-full"
                >
                    +
                </button>
            </div>
            
            <div className="flex-1 overflow-y-auto">
                {channels.map(channel => (
                    <div 
                        key={channel.id}
                        onClick={() => setActiveChannelId(channel.id)}
                        className={`p-4 hover:bg-slate-50 cursor-pointer border-b border-slate-100 transition ${activeChannelId === channel.id ? 'bg-blue-50' : ''}`}
                    >
                        <div className="flex justify-between items-start">
                            <div className="flex items-center gap-3 overflow-hidden">
                                <div className="w-10 h-10 rounded-full bg-slate-200 flex-shrink-0 flex items-center justify-center overflow-hidden">
                                    {getChannelAvatar(channel) ? (
                                        <img src={getChannelAvatar(channel)} alt="" className="w-full h-full object-cover" />
                                    ) : (
                                        <span className="text-slate-500 font-bold">{getChannelName(channel).charAt(0)}</span>
                                    )}
                                </div>
                                <div className="min-w-0">
                                    <div className="font-bold text-slate-700 truncate">{getChannelName(channel)}</div>
                                    <div className="text-xs text-slate-500 truncate">
                                        {channel.lastMessage?.content || '無訊息'}
                                    </div>
                                </div>
                            </div>
                            <div className="flex flex-col items-end gap-1">
                                <span className="text-xs text-slate-400">
                                    {channel.lastMessage?.timestamp ? new Date(channel.lastMessage.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : ''}
                                </span>
                                {channel.unreadCount > 0 && (
                                    <span className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">
                                        {channel.unreadCount}
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
            {activeChannel ? (
                <>
                    <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
                        <div className="flex items-center gap-3">
                            <h3 className="font-bold text-slate-700 text-lg">{getChannelName(activeChannel)}</h3>
                            {activeChannel.type === 'GROUP' && (
                                <span className="text-xs bg-slate-200 px-2 py-1 rounded-full text-slate-600">
                                    {activeChannel.participants.length} 人
                                </span>
                            )}
                        </div>
                        {activeChannel.type === 'GROUP' && (
                            <button 
                                onClick={() => setShowGroupInfoModal(true)}
                                className="text-slate-500 hover:text-blue-600"
                            >
                                ℹ️
                            </button>
                        )}
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50" ref={messagesContainerRef}>
                        {messages.map((msg, index) => {
                            const isMe = msg.userId === currentUser.id;
                            return (
                                <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                                    {!isMe && (
                                        <div className="w-8 h-8 rounded-full bg-slate-300 flex-shrink-0 mr-2 overflow-hidden">
                                            {msg.avatar ? <img src={msg.avatar} alt="" /> : null}
                                        </div>
                                    )}
                                    <div className={`max-w-[70%] ${isMe ? 'items-end' : 'items-start'} flex flex-col`}>
                                        {!isMe && <span className="text-xs text-slate-500 mb-1">{msg.userName}</span>}
                                        <div 
                                            className={`p-3 rounded-2xl text-sm break-words ${
                                                isMe ? 'bg-blue-600 text-white rounded-br-none' : 'bg-white border border-slate-200 text-slate-700 rounded-bl-none'
                                            }`}
                                            onClick={() => isMe && setReadStatusMsg(msg)}
                                        >
                                            {msg.content}
                                        </div>
                                        <span className="text-[10px] text-slate-400 mt-1">
                                            {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                            {isMe && msg.readBy && (
                                                <span className="ml-1">
                                                    {msg.readBy.length > 1 ? `已讀 ${msg.readBy.length - 1}` : '送達'}
                                                </span>
                                            )}
                                        </span>
                                    </div>
                                </div>
                            );
                        })}
                        <div ref={messagesEndRef} />
                    </div>

                    <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-200 bg-white">
                        <div className="flex gap-2">
                            <input
                                type="text"
                                value={messageInput}
                                onChange={e => setMessageInput(e.target.value)}
                                placeholder="輸入訊息..."
                                className="flex-1 p-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                            <button 
                                type="submit"
                                disabled={!messageInput.trim()}
                                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                發送
                            </button>
                        </div>
                    </form>
                </>
            ) : (
                <div className="flex-1 flex items-center justify-center text-slate-400 flex-col gap-4">
                    <div className="text-4xl">💬</div>
                    <p>選擇一個聊天室開始對話</p>
                </div>
            )}
        </div>

        {/* Modals */}
        {readStatusMsg && activeChannel && (
            <ChatMessageReadStatusModal 
                isOpen={!!readStatusMsg}
                message={readStatusMsg} 
                channel={activeChannel}
                users={users} 
                departments={departments}
                onClose={() => setReadStatusMsg(null)} 
            />
        )}

        {showCreateGroupModal && (
            <CreateGroupModal
                isOpen={showCreateGroupModal}
                users={users.filter(u => u.id !== currentUser.id)}
                currentUser={currentUser}
                departments={departments}
                onClose={() => setShowCreateGroupModal(false)}
                onCreateGroup={handleCreateGroup}
            />
        )}

        {showGroupInfoModal && activeChannel && (
            <GroupInfoModal
                isOpen={showGroupInfoModal}
                channel={activeChannel}
                users={users}
                currentUser={currentUser}
                departments={departments}
                onClose={() => setShowGroupInfoModal(false)}
                onLeaveGroup={handleLeaveGroup}
                onEditGroup={handleEditGroup}
            />
        )}
    </div>
  );
};
